# Laborator: funcții, metode și importuri pe web
# Student: Ignat Marian-Cezar

BASE_URL = "https://cybercor.org"
TIMEOUT = 10

#Ex 44 Crearea unui modul
import webtools

print(webtools.get_title(webtools.fetch(BASE_URL).text))

#Ex 45 
from webtools import get_title, security_headers

print(get_title(" <title>Pagina mea: </title> "))
print(security_headers(BASE_URL))
#Dacă definim aici o funcție proprie numită get_title, aceasta va înlocui numele importat în acest fișier.

#Ex 46 Blocul main
from webtools import get_status

print("Status:", get_status(BASE_URL))

#Autotestul rulează doar când deschidem direct fișierul webtools.py. Când îl folosim în main.py, autotestul nu pornește, dar funcțiile din webtools.py pot fi folosite în continuare.

#Ex 47 Constante de modul
from webtools import DEFAULT_HEADERS

print(DEFAULT_HEADERS)

#Ex 48 Argumente din linia de comanda
import argparse
from webtools import get_status, get_title, security_headers, fetch

parser = argparse.ArgumentParser()
parser.add_argument("url",nargs="?", default="https://cybercor.org")
args = parser.parse_args()

url = args.url

response = fetch(url)

print("Titlu: ", get_title(response.text))
print("Status: ", get_status(url))
print("Antente: ", security_headers(url))

#Ex 49 Salvarea CSV
import csv
from datetime import datetime
from webtools import check_paths


paths = ["/", "/robots.txt", "/admin"]

results = check_paths("https://cybercor.org", paths)

with open("report.csv", "w", newline="", encoding="utf-8") as file:
    writer = csv.DictWriter(
        file,
        fieldnames=["path", "status", "checked_at"]
    )

    writer.writeheader()

    for result in results:
        writer.writerow({
            "path": result["path"],
            "status": result["status"],
            "checked_at": datetime.now().isoformat()
        })

print("Raportul a fost salvat!")

#Ex 50 Proiect final
from webtools import site_report
site_report(BASE_URL)