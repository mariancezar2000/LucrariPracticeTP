# Laborator: funcții, metode și importuri pe web
# Student: Ignat Marian-Cezar

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10
DEFAULT_HEADERS = {"User-Agent": "webLab-Ignat Marian-Cezar"}

import json
import ssl
import requests
import re
import socket
import time
from urllib.parse import urlparse, urljoin

def fetch(url, timeout=10):
    return requests.get(url, headers=DEFAULT_HEADERS ,timeout=timeout)

def get_status(url):
    return fetch(url).status_code

def score_headers(headers):
    return sum(1 for value in headers.values() if value), len(headers)

def get_title(html):
    match = re.search(r"<title>(.*?)</title>", html, re.IGNORECASE | re.DOTALL) 
    
    if match: 
        return match.group(1).strip() 
    return None

def zileRamase(hostname):
    context = ssl.create_default_context()

    with socket.create_connection((hostname, 443)) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as s:
            cert = s.getpeercert()
            expiry = ssl.cert_time_to_seconds(cert["notAfter"])
    return (expiry - time.time()) // 86400

def security_headers(url):
    response = fetch(url)
    headers = response.headers

    names = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy"
    ]

    return {name: headers.get(name) for name in names}







    
def check_paths(base_url, paths):
    results = []

    for path in paths:
        url = base_url.rstrip("/") + "/" + path.lstrip("/")

        try:
            response = requests.get(url, timeout=10)
            results.append({
                "path": path,
                "status": response.status_code
            })
        except requests.RequestException:
            results.append({
                "path": path,
                "status": "Error"
            })

    return results

def disallowed_paths(text):
    paths = []

    for line in text.splitlines():
        line = line.strip()

        if line.lower().startswith("disallow:"):
            path = line.split(":", 1)[1].strip()
            if path:
                paths.append(path)

    return paths


#FINAL

def site_report(url):
    response = fetch(url)
    host = urlparse(url).hostname
    title = get_title(response.text)
    ip = socket.gethostbyname(host)

    headers = security_headers(url)
    score, total = score_headers(headers)
    cert_days = zileRamase(host)

    http_url = "http://" + urlparse(url).netloc
    http_response = fetch(http_url)
    redirects = []

    for r in http_response.history:
        location = r.headers.get("Location", r.url)
        redirects.append(f"{r.status_code} -> {location}")

    links = re.findall(r'href=["\'](.*?)["\']', response.text)
    internal = 0
    external = 0

    for link in links:
        link_url = urlparse(urljoin(response.url, link))

        if link_url.scheme in ("http", "https"):
            if link_url.hostname == host:
                internal += 1
            elif link_url.hostname:
                external += 1

    robots = fetch(urljoin(response.url, "/robots.txt"))
    forbidden = disallowed_paths(robots.text)

    report = {
        "url": url,
        "status": response.status_code,
        "final_url": response.url,
        "title": title,
        "ip_address": ip,
        "redirects": redirects,
        "security_score": f"{score}/{total}",
        "certificate_days_left": int(cert_days),
        "internal_links": internal,
        "external_links": external,
        "forbidden_paths": forbidden
    }

    print(f"=== Raport site: {url} ===")
    print(f"Cod de stare: {report['status']}")
    print(f"URL final: {report['final_url']}")
    print(f"Titlu: {title}")
    print(f"Adresa IP: {ip}")
    print(f"Redirectionari: {redirects}")
    print(f"Scor securitate: {score}/{total}")
    print(f"Certificat: {int(cert_days)} zile ramase")
    print(f"Legaturi: {internal} interne, {external} externe")
    print(f"Cai interzise: {', '.join(forbidden) or 'Niciuna'}")

    with open("report.json", "w", encoding="utf-8") as file:
        json.dump(report, file, indent=4, ensure_ascii=False)

    print("Salvat in report.json")
    return report



if __name__ == "__main__":
    print("Autotest: ", get_status(BASE_URL))