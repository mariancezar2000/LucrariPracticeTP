# Laborator: funcții, metode și importuri pe web
# Student: Ignat Marian-Cezar

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

#Ex 35 Descompunerea unui URL
from urllib.parse import urlparse

url = "https://cybercor.org/path?x=1#top"

results = urlparse(url)

print("Schrma: ", results.scheme)
print("Netlock: ", results.netloc)
print("Path: ", results.path)
print("Query: ", results.query)
print("Fragment: ", results.fragment)

#Ex 36 Compunerea URL-ului
from urllib.parse import urljoin

print(urljoin(BASE_URL, "/about"))
print(urljoin(BASE_URL, "contact.html"))
print(urljoin(BASE_URL, "../index.html"))

#Ex 37Extragerea legaturilor
import re
import requests

def extract_links(html):
    links = re.findall(r'href="([^"]+)"', html)
    return list(set(links))

response = requests.get(BASE_URL, timeout=TIMEOUT)
html = response.text

print(extract_links(html))

#Ex 38 Interne sau externe
from urllib.parse import urljoin, urlparse

def split_links(links, domain):
    interne = []
    externe = []

    for link in links:
        url = urljoin(domain, link)
        if urlparse(url).netloc == urlparse(domain).netloc:
            interne.append(url)
        else:
            externe.append(url)

    return interne, externe

links = ["/about", "contact.html", "https://google.com", "https://youtube.com"]

interne, externe = split_links(links, BASE_URL)
print("Legaturi interne: ", interne)
print("Legaturi externe: ", externe)

#Ex 39 Propriile metode
from html.parser import HTMLParser

class GasImag(HTMLParser):
    def __init__(self):
        super().__init__()
        self.image = []

    def handle_starttag(self, tag, attrs):
        if tag == "img":
            src = dict(attrs).get("src")
            if src:
                self.image.append(src)
        pass

html = '<img src="/logo.png" alt="Logo"><img src="/photo.jpg">'

finder = GasImag()
finder.feed(html)

print(finder.image)

#Testare
from html.parser import HTMLParser

class GasImag(HTMLParser):
    def __init__(self):
        super().__init__()
        self.images = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() == "img":
            src = dict(attrs).get("src")
            if src:
                self.images.append(src)


test_html = """
<html><body>
  <img src="/logo.png" alt="Logo">
  <IMG SRC="poza.jpg">
  <img alt="imagine fără src">
  <img src="https://cdn.example.com/banner.webp" />
  <a href="/despre">Aceasta nu este o imagine</a>
</body></html>
"""

finder = GasImag()
finder.feed(test_html)

print(finder.images)

assert finder.images == [
    "/logo.png",
    "poza.jpg",
    "https://cdn.example.com/banner.webp",
], "Parserul nu a găsit exact imaginile așteptate"

print("Testul a trecut!")

#Testare real
response = requests.get(BASE_URL, timeout=TIMEOUT)

finder = GasImag()
finder.feed(response.text)

print(len(finder.images), "imagini găsite")

for src in finder.images:
    print(src)

#Ex 40 Amprente
import requests
import hashlib

def page_fingerprint(url):
    rsponse=requests.get(url, timeout=TIMEOUT)
    return hashlib.sha256(response.content).hexdigest()

amprenta1 = page_fingerprint(BASE_URL)
amprenta2 = page_fingerprint(BASE_URL)

print("Amprenta 1: ", amprenta1)
print("Amprenta 2: ", amprenta2)

if amprenta1 == amprenta2:
    print("Amprentele sunt identice.")
else:
    print("Amprente diferite.")
#Ar fi diferite daca se schimba macar un bit din continut, cum ar fi: pagina actualizata, schimbare textului/img

#Ex 41 JSON
import json

response = requests.get(BASE_URL, timeout=TIMEOUT)

#Salvarea antentelor in JSON
with open("headers.json", "w", encoding="utf-8") as file:
    json.dump(dict(response.headers), file, indent=2)

#Citirea antentelor din JSON
with open("headers.json", "r", encoding="utf-8") as file:
    headers = json.load(file)

#Afisarea unui atent
print(headers.get("Content-type", "Antentul nu exista"))

#Ex 42 Intergarea DNS
import socket

def resolve(hostname):
    return socket.gethostbyname(hostname)

print(resolve("cybercor.org"))

#Ex 42 Expirarea Certificatului
import socket
import ssl
import time

def zileRamase(hostname):
    context = ssl.create_default_context()

    with socket.create_connection((hostname, 443)) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as s:
            cert = s.getpeercert()
            expiry = ssl.cert_time_to_seconds(cert["notAfter"])
    return (expiry - time.time()) // 86400

print(zileRamase("cybercor.org"))
