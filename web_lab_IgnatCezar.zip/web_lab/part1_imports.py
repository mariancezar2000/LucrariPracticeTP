# Laborator: funcții, metode și importuri pe web
# Student: Ignat Marian-Cezar

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


#Exercise 1
import requests

print(requests.__version__)

import urllib.request
#


#Exercise 2 (A) 
import requests

BASE_URL = "https://cybercor.org/robots.txt"

response = requests.get(BASE_URL, timeout=TIMEOUT)
print(response.status_code)
#Este mai calr de unde vine functia

#(B)

from requests import get

BASE_URL = "https://cybercor.org/robots.txt"

response = get(BASE_URL, timeout=TIMEOUT)
print(response.status_code)
#Cod mai scurt, nu mai scriem request.get()

#Exercise 3
import requests as rq

BASE_URL = "https://cybercor.org/robots.txt"

response = rq.get(BASE_URL, timeout=TIMEOUT)
print(response.status_code)

# Un alias face codul mai ușor de citit atunci când numele este lung și este folosit de multe ori.

#Exercise 4
import urllib.request

ECHO_URL = "https://httpbin.org"

response = urllib.request.urlopen(ECHO_URL, timeout=TIMEOUT)
print(response.status)

body = response.read().decode("utf-8")
print(body[:200])


#Exercise 5
import requests
print(dir(requests))

import requests
print(type(requests.utils)) #Ce fel de tip este: functie, modul ...

# get este o funcție.
# HTTPError este o clasă.
# utils este un modul.

#Exercise 6
import requests
help(requests.get)
BASE_URL = "https://cybercor.org/robots.txt"

response = requests.get(BASE_URL, timeout=TIMEOUT)
print(response.status_code)

#Exercise 7
import requests
import time

BASE_URL = "http://cybercor.org/robots.txt"

start = time.perf_counter()
response = requests.get(BASE_URL, timeout = TIMEOUT)
end = time.perf_counter()

duration = end - start
print("Timpul masurat", duration, "sec.")
print("Compararea: ", response.elapsed)

#Exercise 8
try:
    import bs4
except ImportError:
    print("Instalati modulul cu: pip install beautifulsoup4.")

#Modul - un fisier .py aflat in folder.
#Pachet - un foldet cu mai multe module.
#Biblioteca - o colectie de cod cu mai multe pachete si module.
