# Laborator: funcții, metode și importuri pe web
# Student: Ignat Marian-Cezar

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

#Ex 21 Prima Functie
import requests
import time

BASE_URL = "http://cybercor.org/robots.txt"

response = requests.get(BASE_URL, timeout = TIMEOUT)

def fetch(url):
    response = requests.get(url, timeout=TIMEOUT)
    return response

response = fetch(BASE_URL)
print(response.status_code)

#Ex 22 Returnarea unei singuri valori

def get_status(url):
    response= requests.get(url, timeout=TIMEOUT)
    return response.status_code

print(get_status(BASE_URL + "/"))
time.sleep(1)

print(get_status(BASE_URL + "/robots.txt"))
time.sleep(1)

print(get_status(BASE_URL + "/sitemap.xml"))

#Ex 23 Parametri implicati
def fetch(url, timeout=TIMEOUT):
    response = requests.get(url,timeout=timeout)
    return response.status_code

url = "http://cybercor.org/robots.txt"

print(fetch(url))
print(fetch(url, timeout=3))

#Ex 24 O singura sarcina pe functie
def get_title(html):
    start = html.find("<title>") + 7
    end = html.find("</tittle>")
    return html[start:end]

html = requests.get(BASE_URL, timeout=TIMEOUT).text
print(get_title(html))

#Ex 25 Docstring-uri
def get_title(html):
    start = html.find("<title>") + 7
    end = html.find("</title>")
    return html[start:end]


help(get_title)

#Ex 26 Adnotari de tip
def get_status(url: str) -> int:
    return 200
    
print(get_status(123))

#Ex 27 Fara opriri neasteptate
def page_exists(url):
    try:
        requests.get(url, timeout=TIMEOUT)
        return True
    except requests.RequestException:
        return False

print(page_exists("http://cybercor.org/robots.txt"))
print(page_exists("https://this-domain-does-not-exist.invalid"))

#Ex 28 Returnarea unui dictionar 
def check_paths(base, paths):
    result = {}

    for path in paths:
        url = base + path
        response=requests.get(url)
        result[path]=response.status_code
    return result
paths = ["/", "/robots.txt", "/sitemap.xml"]

print(check_paths("http://cybercor.org/robot.txt", paths))

#Ex 29 Argumente cu nume
def get_header(url, name, default="lipsește"):
    response = requests.get(url)
    return response.headers.get(name, default)

print(get_header(BASE_URL, name="Server"))

#Ex 30 Antente de securitate
def security_headers(url):
    response = requests.get(url, timeout=TIMEOUT)

    headers = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy"
    ]
    return {header:header in response.headers for header in headers}

print(security_headers(BASE_URL))

#Ex 31 Fucntii care apeleaza functii
def score_headers(results):
    total = len(results)
    present = sum(results.values())
    return f"{present}/{total}"

print(score_headers(security_headers(BASE_URL)))

#Ex 32 Doua functii, o sarcina
def fetch_robots(base):
        try:
            response = requests.get(base + "/robots.txt", timeout=TIMEOUT)
            if response.status_code == 404:
                return None
            return response.text
        except requests.RequestException:
            return response.text

def disallowed_paths(robots_text):
    if robots_text is None:
        return[]
    
    paths = []

    for line in robots_text.splitlines():
        if line.startswith("Disallow"):
            path = line.split(":", 1)[1].strip()
            paths.append(path)
    return paths

print(disallowed_paths(fetch_robots(BASE_URL)))

#Ex 33 Oricate argumente
def response_time(*urls):
    results = {}

    for url in urls:
        start = time.time()
        requests.get(url)
        end = time.time()
        
        results[url] = end - start

        return results
    
    print(response_time("http://cybercor.org/robot.txt", "https://google.com"))

    #Ex 34 Argumente cu nume colectate
    BASE_URL = "https://cybercor.org"

    def log(message, **details):
        print(message, end="")

        for key, value in details.items():
            print(f" | {key}={value}", end="")

        print()

    log("verificat", url=BASE_URL, status=200)
