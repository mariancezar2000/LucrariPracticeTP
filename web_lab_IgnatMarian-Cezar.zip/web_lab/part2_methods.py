# Laborator: funcții, metode și importuri pe web
# Student: Ignat Marian-Cezar

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

#Exercise 9
import requests

BASE_URL = "http://cybercor.org/robots.txt"

response = requests.get(BASE_URL, timeout = TIMEOUT)
print(response.status_code) #atribut, care arata codul de stare     
print(response.ok)     # atribut, arata daca este ok sau nu ok
print(response.url)    #atribut, arata denumirea la link web
print(response.encoding)    #atribut, huio znaet ce face
#Sunt atribute deaorece nu au paranteze, doar metodele au.

#Ex 10

response =  requests.get(BASE_URL, timeout = TIMEOUT)
response.raise_for_status()

try:
    response = requests.get("/this-page-does-not-exist", timeout=TIMEOUT)
except:
    requests.HTTPError
    print("Pagina neregasita, пошол назад.")
    
#Ex 11
import requests

BASE_URL = "http://cybercor.org/robots.txt"

response =  requests.get(BASE_URL, timeout = TIMEOUT)
for name, valoare in response.headers.items():
    print (name,":", valoare)


#Ex 12
import requests

BASE_URL = "http://cybercor.org/robots.txt"

response =  requests.get(BASE_URL, timeout = TIMEOUT)

print(response.headers.get("Server", "lipseste"))
print(response.headers.get("Content-type", "lipseste"))

print(response.headers.get("content-type", "lipseste"))
#Ca cele doua content, reactionez la fel, adica nu conteaza daca litera e majuscul sau nu

#Ex 13
import requests

BASE_URL = "http://cybercor.org/robots.txt"

response =  requests.get(BASE_URL, timeout = TIMEOUT)
print(response.text.lower().count("cyber"))
#Putem inlatui cout si lower, deaorece ele rturneaza doar valorile, tranformand litere mari in mici si de cate ori se gaseste cuvantul dat

#Ex 14: Gasirea titlului
import requests

BASE_URL = "http://cybercor.org/robots.txt"

response =  requests.get(BASE_URL, timeout = TIMEOUT)
html = response.text
start = html.find("<title>") + len("<title>")
end = html.find("<title>")

title = html[start:end].strip()
print(title)


#Ex 15
import requests

BASE_URL = "http://cybercor.org/robots.txt"

response =  requests.get(BASE_URL, timeout = TIMEOUT)
lines = response.text.splitlines() #impartire codul HTML in linii
print("Numarul linilor:", len(lines))
long_line = max(lines, key=len)
print("Lungimea celei mai lugi linie: ", len(long_line))

#Ex 16
import requests
BASE_URL = "http://cybercor.org/robots.txt"

response =  requests.get(BASE_URL, timeout = TIMEOUT)
ver = response.text.startswith("https://")
if ver:
    print("Conexiune securizata.")
else:
    print("Conexiune nesecurizata.")

print(ver)


#Ex 17 Urmarirea redirectionarilor
import requests
BASE_URL = "http://cybercor.org/robots.txt"

response =  requests.get(BASE_URL, timeout = TIMEOUT)
for hy in response.history:
    print(hy.status_code, ",", hy.url)

print("URL final: ", response.url)

#Ex 18 
import requests
BASE_URL = "http://cybercor.org/robots.txt"

response =  requests.get(BASE_URL, timeout = TIMEOUT)
requiet = requests.head(BASE_URL, timeout = TIMEOUT)

print("Head: ", len(requiet.content))
print("Get: ", len(response.content))

#Ex 19
import requests
BASE_URL = "http://cybercor.org/robots.txt"

response = requests.get(BASE_URL, timeout=TIMEOUT)

if response.cookies:
    for cookie in response.cookies:
        print("Nnume: ",cookie.name)
        print("Secure: ", cookie.secure)
    else:
        print("Niciune cookie atestat.")

#Ex 20
import requests
BASE_URL = "http://cybercor.org/robots.txt"
ECHO_URL = "https://httpbin.org"

response = requests.get(BASE_URL, timeout=TIMEOUT)

session = requests.session()
session.headers.update({"User-Agent": "Weblab-Ignat Marian-Cezar"})
session.get(ECHO_URL + "/headers")

print(response.text)
