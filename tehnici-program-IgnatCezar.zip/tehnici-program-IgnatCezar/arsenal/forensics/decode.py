#A1
s = "Salut"
b = s.encode()

print(b)
print(b[0])
 #Transformare bytes din hex
print(b.hex())
#Refacem bytes in hex
b2 = bytes.fromhex(b.hex())
print(b2)

#A2 recunoașterea tipului de codare
import re
def ghici_strat(s):
    if re.search(r"%[0-9a-fA-F]{2}", s):
        return "url"

    if re.fullmatch(r"[0-9a-fA-F]+", s) and len(s) % 2 == 0:
        return "hex"

    if re.fullmatch(r"[A-Za-z0-9+/]*={0,2}", s) and len(s) % 4 == 0:
        return "base64"

    return "necunoscut"

print(ghici_strat("%2Fetc"))
print(ghici_strat("48656c6c6f"))
print(ghici_strat("U2FsdXQ="))
print(ghici_strat("Salut!"))

#A3
import base64
from urllib.parse import unquote

def desfa(s):
    strat = ghici_strat(s)

    # TODO: pentru fiecare strat, decodeaza
    if strat == "base64":
        rezultat = base64.b64decode(s)
    elif strat == "hex":
        rezultat = bytes.fromhex(s)
    elif strat == "url":
        rezultat = unquote(s).encode()
    else:
        rezultat = s.encode()

    # intoarce (strat, rezultat_bytes)
    return strat, rezultat

#A4 Decodarea straturilor multiple
def citibil(b):
    # TODO: True daca toti octetii sunt 32..126
    return all(32 <= c < 127 for c in b)
 
val = "NTM1OTU3NTk="
for i in range(8):
    strat, b = desfa(val)

    print("Strat: ", strat)
    print("Rezultat: ", b)

    if citibil(b):
        print("Mesaj final: ", b.decode())
        break
    val = b.decode()

    #A5 Spargerea criptării XOR.
date = open("probe/xor.bin", "rb").read()

for cheie in range(256):
    rezultat = bytes(b ^ cheie for b in date)

    if all(32 <= b <= 126 for b in rezultat):
        print("Cheia:", cheie)
        print("Mesajul:", rezultat.decode())
        break


#A6 spargerea unui hash prin dictionar
import hashlib
tinta = open("probe/hashuri.txt").readline().strip()
print(len(tinta))   # 32 md5 / 40 sha1 / 64 sha256
for cuv in open("probe/wordlist.txt", encoding="latin1"):
    cuv = cuv.strip()
    if hashlib.md5(cuv.encode()).hexdigest() == tinta:
        print("Gasit:", cuv)
        break

#A7 Ultimul pas
import argparse
import json
import os

p = argparse.ArgumentParser()
p.add_argument("intrare")  # Șir de text sau calea fișierului
p.add_argument("--fisier", action="store_true")
a = p.parse_args()

# Citim datele de intrare
if a.fisier:
    with open(a.intrare, "rb") as f:
        date = f.read()
    strat = "fisier"
else:
    date = a.intrare.encode()
    strat = ghici_strat(a.intrare)

# Pregătim informațiile pentru JSON
fisa = {
    "strat": strat,
    "rezultat": date.hex()
}

# Creăm folderul dacă nu există
os.makedirs("arsenal/forensics", exist_ok=True)

# Salvăm rezultatul în fisa.json
with open("arsenal/forensics/fisa.json", "w", encoding="utf-8") as f:
    json.dump(fisa, f, indent=4, ensure_ascii=False)

print("Rezultatul a fost salvat în fisa.json")



#B1
def tip_real(cale):
    cap = open(cale, "rb").read(8)
    if cap.startswith(b"%PDF"):
        return "pdf"
    elif cap.startswith(b"\x89PNG"):
        return "png"
    elif cap.startswith(b"\xff\xd8"):
        return "jpeg"
    elif cap.startswith(b"PK\x03\x04"):
        return "zip/dock"
    
    return cap.hex() 

print(tip_real("probe/foto.jpg"))

#B2
import re
date = open("probe/ascuns.png", "rb").read()
for m in re.findall(rb"[-\~]{4,}", date):
    print(m.decode())
# cauta un indiciu: o cale, un mesaj, un nume de fisier

#B3
from PIL import Image
from PIL.ExifTags import TAGS
exif = Image.open("probe/foto.jpg")._getexif() or {}
for id, val in exif.items():
    print(TAGS.get(id, id), "=", val)
# TODO: ia blocul GPS (tag 34853) si tipareste
#       latitudinea si longitudinea
gps = exif.get(34853)
if gps:
    print("GPS: ", gps)
    print("Latitudinea: ", gps.get(2))
    print("Longitudinea: ", gps.get(4))


#B4
date = open("probe/ascuns.png", "rb").read()
i = date.find(b"PK\x03\x04")
if i != -1:
    open("gasit.zip", "wb").write(date[i:])
    print("Arhiva extrasa de la octetul ", i )
else:
    print("Arhiva ZIP nu a fost gasita.")

#B5 Ascunzi un mesaj prin LSB
from PIL import Image

img = Image.open("probe/foto.jpg").convert("RGB")

px = list(img.getdata())

mesaj = b"FLAG{ascuns_in_pixeli}\x00"

biti = "".join(f"{x:08b}" for x in mesaj)

px_nou = []
i = 0

for r, g, b in px:
    canale = [r, g, b]

    for j in range(3):
        if i < len(biti):
            canale[j] = (canale[j] & ~1) | int(biti[i])
            i += 1

    px_nou.append(tuple(canale))

img.putdata(px_nou)
img.save("stego.png")

print("Mesajul a fost ascuns în stego.png")


#B6 Dezvălui mesajul înapoi   
from PIL import Image

px = list(Image.open("stego.png").convert("RGB").getdata())

biti = ""

for (r, g, b) in px:
    # Adunam ultimii biti din fiecare canal
    biti += str(r & 1)
    biti += str(g & 1)
    biti += str(b & 1)

# Regrupam bitii cate 8 si reconstruim mesajul
mesaj = b""

for i in range(0, len(biti) - 7, 8):
    octet = int(biti[i:i+8], 2)

    # Ne oprim la primul octet 0
    if octet == 0:
        break

    mesaj += bytes([octet])

print("Mesajul ascuns este:", mesaj.decode("utf-8"))